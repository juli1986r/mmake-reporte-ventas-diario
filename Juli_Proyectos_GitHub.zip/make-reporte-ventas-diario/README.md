# 📊 Reporte de Ventas Diario Automatizado (Make)

Este proyecto simula una automatización en [Make (Integromat)](https://www.make.com) para generar y enviar reportes diarios de ventas extraídos desde Google Sheets.

## 🧩 Flujo:
1. Lectura de Google Sheet con ventas.
2. Filtro y resumen de totales por producto.
3. Generación de PDF con resumen.
4. Envío automático por email al equipo comercial a las 18:00hs.

## 🔧 Herramientas:
- Make (Integromat)
- Google Sheets
- Gmail
- Google Docs PDF Generator

## 🧠 Objetivo:
Reducir el trabajo manual diario y asegurar consistencia en reportes.
