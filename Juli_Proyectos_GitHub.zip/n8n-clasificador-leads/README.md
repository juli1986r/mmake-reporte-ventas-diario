# 📥 Clasificador Automático de Leads (n8n)

Este flujo de trabajo en [n8n](https://n8n.io) clasifica formularios de contacto según palabras clave, conectando con CRM o Soporte automáticamente.

## 🧩 Flujo:
1. Webhook recibe datos del formulario.
2. Script JS clasifica según contenido del mensaje.
3. Ruta dinámica:
   - Lead a CRM (Salesforce)
   - Ticket a Soporte
4. Registro en Airtable

## 🛠 Herramientas:
- n8n
- Webhooks
- Salesforce API
- Airtable
- JavaScript custom function

## 🎯 Resultado esperado:
Acelera el lead scoring y reduce errores manuales.
