# 📈 Monitor Inteligente de Anomalías (Make + Python)

Este proyecto simula un flujo automatizado que detecta métricas anómalas en un archivo de Excel usando inteligencia artificial (IA) y lo comunica automáticamente.

## 🧩 Flujo:
1. Make monitorea un archivo en OneDrive.
2. Llama un script Python (scikit-learn) para detectar outliers.
3. Si detecta anomalías:
   - Notifica por Microsoft Teams
   - Actualiza tabla en Power BI
   - Log en Google Sheets

## 🧠 Algoritmo:
- Isolation Forest (scikit-learn)

## 📎 Herramientas:
- Make (Integromat)
- Python
- scikit-learn
- Power BI
- Google Sheets API
