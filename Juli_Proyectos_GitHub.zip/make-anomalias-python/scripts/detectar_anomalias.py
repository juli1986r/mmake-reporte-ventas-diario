import pandas as pd
from sklearn.ensemble import IsolationForest

# Simula detección de anomalías en un archivo de Excel
def detectar_anomalias(path):
    df = pd.read_excel(path)
    modelo = IsolationForest(contamination=0.05, random_state=42)
    df['anomaly'] = modelo.fit_predict(df.select_dtypes(include='number'))
    return df[df['anomaly'] == -1]

# Ejemplo de uso
if __name__ == "__main__":
    anomalías = detectar_anomalias("ventas.xlsx")
    print(anomalías)
